package sws1007;

public class ex6_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s = new Student("ȫ�浿",1,1,100,60,76);
		
		System.out.println(s.info());
	}
}

class Student{
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;
	
	int getTotal(){
		return (kor + eng + math);
	}
	
	float getAverage(){
		return (int)((getTotal()/(float)3)*10+0.5)/10f;
	}
	
	String info(){
		return name+","+ban+","+no+","+kor+","+eng+","+math+","+getTotal()+","+getAverage();
	}
}