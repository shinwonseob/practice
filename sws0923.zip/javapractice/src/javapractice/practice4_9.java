package javapractice;

public class practice4_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "12345";
		int sum = 0;
		
		for(int i =0; i < str.length(); i++){
			//char ch = ;
			sum = str.charAt(i) - '0' + sum;
			
	
		}
		
		System.out.printf("sum="+sum);
		
	}

}
