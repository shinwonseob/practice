package javapractice;

public class practice4_12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 2;
		int j, a;
		
		for(i=2; i<10; i++){
			for(j=1; j<=3; j++ ){
				a=i*j;
				System.out.printf("%d*%d=%d\n",i,j,a);
				
			}
			System.out.println();
		}
			
	}

}
