/*package javapractice;

public class practice4_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0; i<=10; i++){
			for(int j=0; j<=i; j++)
				System.out.print("*");
		System.out.println();
	 }
   }//end of main
}// end of class
*/
package javapractice;

public class practice4_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		int i = 0;
			
		while(i<=10){
			int j = 0;
			while(j<=i){
				System.out.printf("*");
				j++;}
				
			i++;
			System.out.println();
		}
	}
 }
   

