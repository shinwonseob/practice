package javapractice;

public class practice3_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num =456;
		
		num = num/100;
		num = num*100;
		
		System.out.printf("%d",num);
	}

}
