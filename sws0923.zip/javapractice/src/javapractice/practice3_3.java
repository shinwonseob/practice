package javapractice;

public class practice3_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 10;
		
		if(num ==0)
		System.out.println("0");
		else if(num>0)
		System.out.println("���");
		else if(num<0)
			System.out.println("����");
	}

}

