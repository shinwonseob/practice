package javapractice;

public class practice3_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch = 'z';
		
			boolean b =  (ch<=122)||(97<=ch)||(ch<=90)||(65<=ch)||(ch<=58)||(48<=ch);
				
		System.out.println(b);
	}

}
