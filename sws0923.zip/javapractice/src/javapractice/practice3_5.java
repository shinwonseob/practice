package javapractice;

public class practice3_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 333;
		
		num = num/10;
		num = num * 10 + 1;
		
		System.out.printf("%d",num);
	}

}
