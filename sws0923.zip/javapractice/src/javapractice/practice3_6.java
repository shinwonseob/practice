package javapractice;

public class practice3_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 24;
		int mul;
		int result;
		
		mul = (num/10 + 1)*10;
		
		result = mul - num;
		
		System.out.printf("%d",result);
	}

}
