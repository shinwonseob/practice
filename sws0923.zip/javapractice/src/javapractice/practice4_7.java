package javapractice;

public class practice4_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int value = (int)(Math.random()*6)+1;
		
		System.out.println("value:"+value);
	}

}
