package javapractice;

public class practice3_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fahrenheit = 100;
		float celcius;			
	
		celcius = 5 / (float)9.0 * (fahrenheit-32);
		
		celcius = (int)(celcius * 100 + 0.5)/100f;
		
		System.out.printf("fahrenheit : %d\n",fahrenheit);
		System.out.printf("celcius:"+celcius);
				
				
	}

}
