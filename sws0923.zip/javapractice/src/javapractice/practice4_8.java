package javapractice;

public class practice4_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x =0;
		int y =0;
		
		//x+2y=5
		
		while(x<=10 && x>=0){
			
			y = (int) (-0.5*x + 2.5);
			
			if(x+2*y==5 && y>=0){
				System.out.printf("x=%d",x);
				System.out.printf(" y=%d\n",y);}
			x++;
			}
		}
		
	}

