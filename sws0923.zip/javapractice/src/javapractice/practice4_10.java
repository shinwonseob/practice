package javapractice;

public class practice4_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 12345;
		int sum = 0;
		
		 sum = num%10 + num%100/10 + num%1000/100 + num%10000/1000 + num%100000/10000;
		
		
	System.out.println("sum="+sum);	
	}

}
