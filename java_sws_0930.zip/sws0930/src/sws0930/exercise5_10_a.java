package sws0930;

public class exercise5_10_a {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] abcCode = 
			{'`', '~', '!', 'a', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_', '+', '=',
					 '|', '[', ']', '{', '}', ';', ':', ',', '.', '/'};
			}

		char [] numCode = { 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p' };
		
		String src = "abc123";
		String result = " ";
	
		for(int i=0; i < src.length(); i++){
			char ch = src.charAt(i);
		
			if(ch-96>0 && ch-96<27)
				result = numCode[i];
			else
				result = abcCode[i];
		}
	
		System.out.println("src:"+src);
		System.out.println("result:"+result);
	}

}

