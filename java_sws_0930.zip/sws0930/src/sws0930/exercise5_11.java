package sws0930;

public class exercise5_11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] score = {
				{100, 100, 100},
				{20, 20, 20},
				{30, 30, 30},
				{40, 40, 40},
				{50, 50, 50}
		};
		
		int [][] result = new int[score.length+1][score[0].length+1];
		
		int sum = 0;
		
		for(int i=0; i < score.length;i++){
			for(int j=0; j < score[i].length;j++){
			
				result[i][j]=score[i][j];
				result[i][score[0].length] += result[i][j];
				result[score.length][j] += result[i][j];
				result[score.length][score[0].length] += result[i][j];
				
			}
		}	
				/*	sum += score[i][j];
			}
			
			result[i][score[0].length] = sum;
			sum=0;
	}
	
		int sum2 = 0;
		
		for(int i=0; i < score[0].length;i++){
			for(int j=0; j < score.length;j++){
				sum2 += score[j][i];
			}
			
			result[score.length][i] = sum2;
			sum2 = 0;
	}
		
		
		int sum3 = 0;
		for(int i=1; i < result.length;i++){
				sum3 += result[result[0].length][i];
				result[result[0].length][result.length]=sum3;
		}
				
		int sum4 = 0;
		for(int i=1; i < result[0].length;i++){
			sum4 += result[result[0].length][result.length];		
		}*/
				
				
				
	for(int i=0; i < result.length;i++){
		for(int j=0; j < result[i].length;j++){
			System.out.printf("%4d",result[i][j]);
		}
		System.out.println();
		
		}
	}
}
