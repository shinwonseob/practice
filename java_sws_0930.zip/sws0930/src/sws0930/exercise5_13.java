package sws0930;

import java.util.Scanner;

public class exercise5_13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] words = {"television", "computer", "mouse", "phone"};
		
		Scanner scanner = new Scanner(System.in);
				
		for(int i=0; i<words.length;i++){
			char[] question = words[i].toCharArray();
			
			int j = (int)(Math.random() * (words[i].length()-1));
			int z = (int)(Math.random() * (words[i].length()-1));
			char tmp = 0;
			tmp = question[j];
			question[j] =question[z];
			question[z] = tmp;
		
			
			System.out.printf("Q%d. %s�� ������ �Է��ϼ���.>",
												i+1, new String(question));
			String answer = scanner.nextLine();
			
			if(words[i].equals(answer.trim()))
				System.out.printf("�¾ҽ��ϴ�.%n%n");
			else
				System.out.printf("Ʋ�Ƚ��ϴ�. %n%n");
			
		}
	}

}
