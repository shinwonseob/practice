package sws0930;

public class exercise5_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr = {10, 20, 30, 40, 50};
		int sum = 0;
		int i;
		
		for(i=0; i<5; i++)
		sum = sum + arr [i];
			
	System.out.println("sum="+sum);
	}

}
