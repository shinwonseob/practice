package sws0930;

public class exercise5_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] arr = {
				{5, 5, 5, 5, 5},
				{10, 10, 10, 10, 10},
				{20, 20, 20, 20,20},
				{30, 30, 30, 30, 30}
		};
		
		int total = 0;
		float average = 0;
		int i, j = 0;
		
		for(i=0;i<4;i++)
			for(j=0; j<5; j++)
				total = total + arr [i][j];
				
		average = total/(float)20;
		
		
		System.out.println("total="+total);
		System.out.println("average="+average);
		}
	}


