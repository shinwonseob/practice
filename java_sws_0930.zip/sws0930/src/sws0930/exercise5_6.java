package sws0930;

public class exercise5_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] coinUnit = {500, 100, 50, 10};
		int [] tmp = new int[4];//�̰� �������� int [] tmp =0���� �ʱ�ȭ �ȵ�
		
		int money = 2680;
		System.out.println("money="+money);
		
		for(int i=0; i<coinUnit.length; i++){
			tmp[i]	= money /  coinUnit[i];
			money = money%coinUnit[i];
		}
	
			System.out.println("500��="+tmp[0]);
			System.out.println("100��="+tmp[1]);
			System.out.println("50��="+tmp[2]);
			System.out.println("10��="+tmp[3]);
		}
	}


