package JDBC;


import java.sql.*;
import java.util.*;

public class ProductDAO {
	
	String jdbcDriver = "com.mysql.jdbc.Driver";
	String jdbcUrl = "jdbc:mysql://localhost/javadb";
	Connection conn;
	
	PreparedStatement pstmt;
	ResultSet rs;
	
	Vector<String> items = null;
	String sql;
	
	public Vector<String> getItems(){
		return items;
	}
	
	public ArrayList<Product> getAll(){
		connectDB();
		sql = "select * from product";
		
		ArrayList<Product> datas = new ArrayList<Product>();
		
		items = new Vector<String>();
		items.add("��ü");
		
		try{
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				Product p = new Product();
				p.setProcode(rs.getInt("prcode"));
				p.setPrname(rs.getString("prname"));
				p.setPrice(rs.getInt("price"));
				p.setManufacture(rs.getString("manufacture"));
				datas.add(p);
				items.add(String.valueOf(rs.getInt("prcode")));
			}
		} catch (SQLException e){
			e.printStackTrace();
			return null;
		} finally {
			closeDB();
		}
		return datas;
	}

	public Product getProduct(int prcode){
		connectDB();
		sql = "select * from product where prcode = ?";
		Product p = null;
		try{
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,  prcode);
			rs = pstmt.executeQuery();
			rs.next();
			p = new Product();
			p.setProcode(rs.getInt("prcode"));
			p.setPrname(rs.getString("prname"));
			p.setPrice(rs.getInt("price"));
			p.setManufacture(rs.getString("manufacture"));
		} catch (SQLException e){
			e.printStackTrace();
			return null;
		} finally {
			closeDB();
			
		}
		return p;
	}

	
	public boolean newProduct(Product product){
		connectDB();
		
		sql = "insert into product(prname, price, manufacture) values(?, ?, ?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getPrname());
			pstmt.setInt(2, product.getPrice());
			pstmt.executeUpdate();
			
		} catch (SQLException e){
			e.printStackTrace();
			return false;
		} finally {
			closeDB();
		}
		return true;
	}
	
	
	
	public boolean delProduct(int prcode){
		connectDB();
		sql = "delete from product where prcode = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, prcode);
			pstmt.executeUpdate();
		} catch (SQLException e){
			e.printStackTrace();
			return false;
		} finally {
			closeDB();
		}
		return true;
	}
	
	
	public boolean updateProduct(Product product){
		connectDB();
		sql = "update product set prname = ?, price = ?, manufacture = ? where prcode = ?";
		try { 
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getPrname());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getManufacture());
			pstmt.setInt(4, product.getProcode());
			pstmt.executeUpdate();
		} catch (SQLException e){
			e.printStackTrace();
			return false;
		} finally {
			closeDB();
		}
		return true;
	
	}
	


	
	public void connectDB(){
		try{
			Class.forName(jdbcDriver);
			conn = DriverManager.getConnection(jdbcUrl, "JDBC","1234");
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void closeDB(){
		try{
			pstmt.close();
			conn.close();
		} catch (SQLException e){
			e.printStackTrace();
		}
	}
}
