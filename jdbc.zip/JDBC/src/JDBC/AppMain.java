package JDBC;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AppMain extends JFrame implements ActionListener {
	public static void main (String [] args) {
		
		 	JButton m1 = new JButton("PAGE_START");
	        JButton p1 = new JButton("LINE_START");
	        JButton p2 = new JButton("CENTER");
	        JButton scroll = new JButton("LINE_END");
	        JButton p3 = new JButton("PAGE_END");
	
		public AppMain(){
			super("Product Manager Application V1.0");
			
			
			this.setSize(300,300);
            this.setVisible(true);

		}
	}
}
